package com.ik.iam.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ik.iam.model.Application;

@Repository
public interface ApplicationRepository extends MongoRepository<Application, String> {

	boolean existsByAppName(String appName);


	Application findByAppName(String appName);
	
	Application findByAppId(Long appId);

}