package com.ik.iam.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.ik.iam.model.User;

@Repository
public interface UserRepository extends MongoRepository<User, String> {

	Optional<User> findByVerificationToken(String token);

	Optional<User> findByEmail(String email);

	@Query("{'email': ?0}")
	User findByEmail1(String email);

	boolean existsByEmail(String email);

	org.apache.el.stream.Optional findByresetPasswordToken(String token);

	Optional<User> findByResetPasswordToken(String token);

	Optional<User> findByResetPasswordToken(Object object);

	@Query("{ 'User_Id' : ?0 }")
	Optional<User> findByUser_Id(Long userId);

	List<User> findBynameIgnoreCase(String trim);

	@Query("{ 'User_Id' : ?0 }")
	User findByUser_Id1(Long userId);
	
	//updateByName
	@Query("{ 'name' : ?0 }")
	User findByname(String name);
	
	//TODO: today's change
//Delete User ByName
	User deleteByname(String name);
	
//	@Query("{ 'User_Id' : ?0 }")
//	Optional<User> existsByUser_Id(Long userId);

	



	
	

}