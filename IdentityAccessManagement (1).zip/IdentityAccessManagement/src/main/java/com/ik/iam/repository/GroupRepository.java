package com.ik.iam.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.ik.iam.model.Group;

@Repository
public interface GroupRepository extends MongoRepository<Group, String>{

//	Group findByGroupName(String groupName);
    boolean existsByGroupName(String groupName);
    
	@Query("{ 'Group_Id' : ?0 }")
	Optional<Group> findByGroup_Id(Long groupId); // Update the method name to findByUser_Id

	void deleteBygroupName(String groupName);

	Optional<Group> findByGroupName(String groupName);


	@Query("{ 'groupName' : ?0 }")
	Group findByGroupName1(String groupName);

}
