package com.ik.iam.repository;



import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.ik.iam.model.UserRoleApp;

@Repository
public interface UserRoleAppRepository extends MongoRepository<UserRoleApp, String> {

//    @Query("{'user_Id': ?0, 'role_Id': ?1, 'app_Id': ?2}")
//    boolean existsByUser_IdAndRole_IdAndApp_Id(Long userId, Long roleId, Long appId);

}
