package com.ik.iam.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "permission")

public class Permission {

	
	
	
}
