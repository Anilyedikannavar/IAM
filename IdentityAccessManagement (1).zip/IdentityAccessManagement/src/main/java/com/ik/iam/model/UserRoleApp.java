package com.ik.iam.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Document(collection = "UserRoleApp")
public class UserRoleApp {

	
	    @Id
	    @JsonIgnore
	    private String id; // Assuming you still want an _id field, you can customize this

	    @Field(name = "User_Id")
	    private long userId;
	    private String userName;
	    
	    @Field("Role_Id")
	    private long roleId;
	    private String roleName;
	    
	    @Field("App_Id")
	    private long appId;
	    private String appName;
	    
	 // Constructors, getters, setters, etc.
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public long getRoleId() {
			return roleId;
		}
		public void setRoleId(long roleId) {
			this.roleId = roleId;
		}
		public String getRoleName() {
			return roleName;
		}
		public void setRoleName(String roleName) {
			this.roleName = roleName;
		}
		public long getAppId() {
			return appId;
		}
		public void setAppId(long appId) {
			this.appId = appId;
		}
		public String getAppName() {
			return appName;
		}
		public void setAppName(String appName) {
			this.appName = appName;
		}
	    
	 
		
	
	
    
   
}
