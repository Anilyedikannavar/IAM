package com.ik.iam.services;

import org.springframework.stereotype.Service;

import com.ik.iam.actionHandler.BaseActionHandler;

@Service
public class Permission extends BaseActionHandler {

}
