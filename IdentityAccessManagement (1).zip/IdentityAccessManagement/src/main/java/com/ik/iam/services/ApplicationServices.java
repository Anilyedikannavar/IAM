package com.ik.iam.services;

import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.ik.iam.actionHandler.BaseActionHandler;
import com.ik.iam.model.Application;
import com.ik.iam.repository.ApplicationRepository;
import com.ik.iam.sequnceGenerator.SequenceGeneratorService;

@Service
public class ApplicationServices extends BaseActionHandler {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private SequenceGeneratorService sequenceGeneratorService;

    public void addApp(Map<String, Object> requestData) {
        String appName = (String) requestData.get("appName");
        String appDesc = (String) requestData.get("appDesc");

        if (applicationRepository.existsByAppName(appName)) {
            throw new IllegalArgumentException("App name is already taken!");
        }

        long appId = sequenceGeneratorService.generateSequence("App_Id");

        Application newApp = new Application();
        newApp.setApplicationId(appId);
        newApp.setAppName(appName);
        newApp.setAppDesc(appDesc);
        applicationRepository.save(newApp);
    }

    public ResponseEntity<String> getByAppName(String appName) {
        Application application = applicationRepository.findByAppName(appName);

        if (application != null) {
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("appId", application.getAppId());
            responseData.put("appName", application.getAppName());
            responseData.put("appDesc", application.getAppDesc());

            String jsonResponse = "{\n" +
                    "  \"appId\": \"" + application.getAppId() + "\",\n" +
                    "  \"appName\": \"" + application.getAppName() + "\",\n" +
                    "  \"appDesc\": \"" + application.getAppDesc() + "\"\n" +
                    "}";

            return ResponseEntity.ok(jsonResponse);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Application not found for name: " + appName);
        }
    }

    public ResponseEntity<String> updateByAppName(String appName, Map<String, Object> requestData) {
        Application existingApp = applicationRepository.findByAppName(appName);

        if (existingApp != null) {
            // Update the application properties based on the requestData
            // For example, assuming "appDesc" can be updated:
            if (requestData.containsKey("appDesc")) {
                String newAppDesc = (String) requestData.get("appDesc");
                existingApp.setAppDesc(newAppDesc);
                // Save the updated application
                applicationRepository.save(existingApp);

                // Prepare and return the response
                Map<String, Object> responseData = new HashMap<>();
                responseData.put("appId", existingApp.getAppId());
                responseData.put("appName", existingApp.getAppName());
                responseData.put("appDesc", existingApp.getAppDesc());

                String jsonResponse = "{\n" +
                        "  \"appId\": \"" + existingApp.getAppId() + "\",\n" +
                        "  \"appName\": \"" + existingApp.getAppName() + "\",\n" +
                        "  \"appDesc\": \"" + existingApp.getAppDesc() + "\"\n" +
                        "}";
                return ResponseEntity.ok(jsonResponse);
            } else {
                // If "appDesc" is not present in requestData, you can handle it accordingly
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Missing 'appDesc' in the update request");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Application not found for name: " + appName);
        }
    }
    
    public ResponseEntity<String> deleteByAppName(String appName) {
        Application existingApp = applicationRepository.findByAppName(appName);

        if (existingApp != null) {
            // Delete the application
            applicationRepository.delete(existingApp);

            return ResponseEntity.ok("Application deleted successfully for name: " + appName);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Application not found for name: " + appName);
        }
    }
    
	
}