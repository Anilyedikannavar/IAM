package com.ik.iam.services;

import java.util.List;
import java.util.Map;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ik.iam.actionHandler.BaseActionHandler;
import com.ik.iam.model.Application;
import com.ik.iam.model.Group;
import com.ik.iam.model.Role;
import com.ik.iam.model.User;
import com.ik.iam.model.UserRoleApp;
import com.ik.iam.repository.ApplicationRepository;
import com.ik.iam.repository.RoleRepository;
import com.ik.iam.repository.UserRepository;
import com.ik.iam.repository.UserRoleAppRepository;

@Service
public class UserRoleAppServices extends BaseActionHandler {

    @Autowired
    private UserRoleAppRepository userRoleAppRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    // Add userRole
//    public ResponseEntity<Object> addUserRoleApp(Map<String, Object> requestData) {
//        try {
//            // Extract data from the requestData map
//        	long userId = ((Integer) requestData.get("userId")).longValue();
//        	long roleId = ((Integer) requestData.get("roleId")).longValue();
//        	long appId = ((Integer) requestData.get("appId")).longValue();
//
////            long userId = (long) requestData.get("userId");
//            String userName = (String) requestData.get("userName");
////            long roleId = (long) requestData.get("roleId");
//            String roleName = (String) requestData.get("roleName");
////            long appId = (long) requestData.get("appId");
//            String appName = (String) requestData.get("appName");
//
//            // Logging for debugging
//            System.out.println("userId: " + userId);
//            System.out.println("userName: " + userName);
//            System.out.println("roleId: " + roleId);
//            System.out.println("roleName: " + roleName);
//            System.out.println("appId: " + appId);
//            System.out.println("appName: " + appName);
//            System.out.println("ille asiti");
//
//            // Check if the user, role, and application exist
////            boolean use = userRepository.existsByUser_Id(userId);
////          
////            if(!use) {
////                return ResponseEntity.status(HttpStatus.NOT_FOUND)
////                        .body("User with ID " + userId + " not found!");
////            }
//            
////            java.util.Optional<User> userr = userRepository.existsByUser_Id(userId);
////            Long id = userr.get().getUserId();
////            System.out.println("ille asit111111i");
////            if(id != 0) {
////            	 System.out.println("ille 2222asiti");
////            	return ResponseEntity.status(HttpStatus.NOT_FOUND)
////                        .body("Role with ID " + roleId + " not found!");
////            }
//          
////            if (!roleRepository.existsByrole_Id(roleId)) {
////                return ResponseEntity.status(HttpStatus.NOT_FOUND)
////                        .body("Role with ID " + roleId + " not found!");
////            }
////
////            if (!applicationRepository.existsById(String.valueOf(appId))) {
////                return ResponseEntity.status(HttpStatus.NOT_FOUND)
////                        .body("Application with ID " + appId + " not found!");
////            }
//
//            // Create a new user role entity and save it
//            UserRoleApp newUserRole = new UserRoleApp();
//            newUserRole.setUserId(userId);
//            newUserRole.setUserName(userName);
//            newUserRole.setRoleId(roleId);
//            newUserRole.setRoleName(roleName);
//            newUserRole.setAppName(appName);
//            newUserRole.setAppId(appId);
//
//            UserRoleApp savedUserRole = userRoleAppRepository.save(newUserRole);
//
//            return ResponseEntity.status(HttpStatus.CREATED).body(savedUserRole);
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error: " + e.getMessage() + ", Cause: " + e.getCause());
//        }
//    }
    
//    public ResponseEntity<Object> addUserRoleApp(Map<String, Object> requestData) {
//        try {
//            // Extract data from the requestData map
//            long userId = ((Integer) requestData.get("userId")).longValue();
//            long roleId = ((Integer) requestData.get("roleId")).longValue();
//            long appId = ((Integer) requestData.get("appId")).longValue();
//
//            // Check if the user, role, and application exist
////            java.util.Optional<User> userOptional = userRepository.findByUser_Id(userId);
//            java.util.Optional<User> userOptional = userRepository.findByUser_Id(userId);
//            if (!userOptional.isPresent()) {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                        .body("User with ID " + userId + " not found!");
//            }
//
////            java.util.Optional<Role> roleOptional = roleRepository.existsByrole_Id(roleId);
//            java.util.Optional<User> roleOptional = roleRepository.findByrole_Id(roleId);
//            if (!roleOptional.isPresent()) {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                        .body("Role with ID " + roleId + " not found!");
//            }
//
////            java.util.Optional<Application> appOptional = applicationRepository.(appId);
////            if (!appOptional.isPresent()) {
////                return ResponseEntity.status(HttpStatus.NOT_FOUND)
////                        .body("Application with ID " + appId + " not found!");
////            }
//
//            // Create a new user role entity and save it
//            UserRoleApp newUserRole = new UserRoleApp();
//            newUserRole.setUserId(userId);
//            newUserRole.setUserName((String) requestData.get("userName"));
//            newUserRole.setRoleId(roleId);
//            newUserRole.setRoleName((String) requestData.get("roleName"));
//            newUserRole.setAppName((String) requestData.get("appName"));
//            newUserRole.setAppId(appId);
//
//            UserRoleApp savedUserRole = userRoleAppRepository.save(newUserRole);
//
//            return ResponseEntity.status(HttpStatus.CREATED).body(savedUserRole);
//        } catch (Exception e) {
//            // Log any exceptions for debugging
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error: " + e.getMessage() + ", Cause: " + e.getCause());
//        }
//    }
    
//    

//    @PostMapping("/add-user-role-app")
    public ResponseEntity<Object> addUserRoleApp(Map<String, Object> requestData) {
        try {
            // Extract data from the requestData map
            long userId = ((Integer) requestData.get("userId")).longValue();
            String userName = (String) requestData.get("name");
            long roleId = ((Integer) requestData.get("roleId")).longValue();
            String roleName = (String) requestData.get("roleName");
            long appId = ((Integer) requestData.get("appId")).longValue();
            String appName = (String) requestData.get("appName");

            // Validate all identifiers
            User user = userRepository.findByUser_Id1(userId);
            if (user == null) {
                throw new Exception("User with ID " + userId + " not found!");
            }

            Role role = roleRepository.findByrole_Id(roleId);
            if (role == null) {
                throw new Exception("Role with ID " + roleId + " not found!");
            }

            Application application = applicationRepository.findByAppId(appId);
            if (application == null) {
                throw new Exception("Application with ID " + appId + " not found!");
            }

            // Create a new user role entity and save it
            UserRoleApp newUserRole = new UserRoleApp();
            newUserRole.setUserId(userId);
            newUserRole.setUserName(userName);
            newUserRole.setRoleId(roleId);
            newUserRole.setRoleName(roleName);
            newUserRole.setAppName(appName);
            newUserRole.setAppId(application.getAppId());

            UserRoleApp savedUserRole = userRoleAppRepository.save(newUserRole);

            return ResponseEntity.status(HttpStatus.CREATED).body(savedUserRole);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }



    
    
    
}
