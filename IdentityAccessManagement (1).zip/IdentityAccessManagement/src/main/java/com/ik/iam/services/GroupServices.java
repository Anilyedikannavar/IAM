 package com.ik.iam.services;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ik.iam.actionHandler.BaseActionHandler;
import com.ik.iam.model.Group;
import com.ik.iam.repository.GroupRepository;
import com.ik.iam.sequnceGenerator.SequenceGeneratorService;

@Service
public class GroupServices extends BaseActionHandler {
	
	@Autowired
	private GroupRepository groupRepository;
	
	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;

	// Update the method signature to accept a Map parameter
	public void addGroup(Map<String, Object> requestData) {
		// Extract group registration data from the requestData map
		String groupName = (String) requestData.get("groupName");
		String groupDescription = (String) requestData.get("groupDescription");

		// Apply validation rules for each attribute
//		    validateAttribute(groupName, "groupName");

		// Check if the group name is already taken
		if (groupRepository.existsByGroupName(groupName)) {
			throw new IllegalArgumentException("Group name is already taken!");
		}

		// Generate group ID
		long groupId = sequenceGeneratorService.generateSequence("Group_Id");
		System.out.println("Generated Group Id: " + groupId);

		// Create a new group entity and save it
		Group newGroup = new Group();
		newGroup.setGroupId(groupId);
		newGroup.setGroupName(groupName);
		newGroup.setGroupDescription(groupDescription);
		groupRepository.save(newGroup);
	}

	public ResponseEntity<?> getGroupById(Long groupId) {
		// Implement your logic to fetch user details from MongoDB based on the provided
		// userId
//			Optional<Group> optionalUser = groupRepository.findBygroupId(groupId);
		Optional<Group> optionalGroup = groupRepository.findByGroup_Id(groupId);

		return optionalGroup.map(group -> {
			System.out.println("Group details: " + group.getGroupDescription());
			System.out.println("User details: " + group.getGroupId());
			System.out.println("User details: " + group.getGroupName());

			return ResponseEntity.ok(group);
//			}).orElseThrow();
		}).orElse(ResponseEntity.notFound().build());
	}

	public ResponseEntity<?> getGroupByName(String groupName) {
		// Implement your logic to fetch group details from MongoDB based on the
		// provided groupName
		Optional<Group> optionalGroup = groupRepository.findByGroupName(groupName);

		return optionalGroup.map(group -> {
			System.out.println("Group details: " + group.getGroupDescription());
			System.out.println("User details: " + group.getGroupId());
			System.out.println("User details: " + group.getGroupName());

			return ResponseEntity.ok(group);
		}).orElse(ResponseEntity.notFound().build());
	}
	
	
	
	@Transactional
    public Group updateGroupByName(String groupName, Map<String, Object> requestData) throws NotFoundException {
        // 1. Check if the group exists by name
        Group existingGroup = groupRepository.findByGroupName1(groupName);
        if (existingGroup == null) {
            throw new NotFoundException();
        }

        // 2. Validate and apply updates from request data
        for (Map.Entry<String, Object> entry : requestData.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            // Check only specific attributes to update
            switch (key) {
                case "groupDescription":
                    if (value instanceof String) {
                        existingGroup.setGroupDescription((String) value);
                    } else {
                        // Handle validation or throw an exception for invalid data type
                        throw new IllegalArgumentException("Invalid data type for groupDescription");
                    }
                    break;
                // Add additional cases for other attributes you want to update
                // case "attributeName":
                //     if (value instanceof Type) {
                //         existingGroup.setAttributeName((Type) value);
                //     } else {
                //         // Handle validation or throw an exception for invalid data type
                //         throw new IllegalArgumentException("Invalid data type for attributeName");
                //     }
                //     break;
                default:
                    // Ignore other attributes or throw an exception for unknown attributes
                    throw new IllegalArgumentException("Unknown attribute: " + key);
            }
        }

        // 3. Save the updated group to MongoDB
        return groupRepository.save(existingGroup);
    }
	
	 public String deleteGroupBygroupName(String groupName) {
		 groupRepository.deleteBygroupName(groupName);
			return "Deleted This Role Successfully";
	    }

	
	
	
	
}
